package src.vue;

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

import src.vue.PanelMap;
import src.modele.Plateau;
import src.modele.Unite;
import src.modele.Terrain;

public class Vue extends JFrame {

  private PanelMap panelPlateau;
  private JLabel labelJoueur, labelInfos;
  private JSplitPane split1, split2;
  private Dimension dimensionEcran;
  private int largeurEcran, hauteurEcran;

  public Vue (PanelMap map) {
    dimensionEcran = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
    largeurEcran = (int)dimensionEcran.getWidth();
    hauteurEcran = (int)dimensionEcran.getHeight();
    setSize(largeurEcran, hauteurEcran);
    setTitle("Advance Wars");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    panelPlateau = map;
    labelJoueur = new JLabel("Informations du joueur", SwingConstants.CENTER);
    formatageTexte(labelJoueur);
    labelJoueur.setOpaque(true);
    labelJoueur.setBackground(new Color(0.3f, 0.3f, 0.3f));
    labelInfos = new JLabel("Informations de la case", SwingConstants.CENTER);
    formatageTexte(labelInfos);
    labelInfos.setOpaque(true);
    labelInfos.setBackground(new Color(0.3f, 0.3f, 0.3f));

    split1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, labelJoueur, labelInfos);
    split1.setDividerSize(2);
    split1.setEnabled(false);
    split1.setDividerLocation(35*hauteurEcran/100);
    getContentPane().add(split1, BorderLayout.CENTER);

    split2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelPlateau, split1);
    split2.setDividerSize(0);
    split2.setEnabled(false);
    split2.setDividerLocation(75*largeurEcran/100);
    getContentPane().add(split2, BorderLayout.CENTER);

    setVisible(true);

  }

  public PanelMap getMap() {
    return panelPlateau;
  }

  public void formatageTexte (JLabel lab) {
    lab.setFont (lab.getFont().deriveFont (25.0f));
    lab.setForeground(Color.WHITE);
  }

  public void informations (Unite unite) {
    String str = "Unité de type " + unite.getNom();
    String str2 = "Possède " + unite.getPV() + " points de vie";
    labelInfos.setText("<html>" + str + "<br>" + str2 + "</html>");
  }

  public void informations (Terrain terrain) {
    String str = "Terrain de type " + terrain.getNom();
    labelInfos.setText(str);
  }

}
