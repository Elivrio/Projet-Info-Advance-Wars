package src.modele;

import java.util.Scanner;
import java.io.*;

public class CarteScanner{
    private Scanner sc;
    private File carte;

    public CarteScanner(String fic){
        sc = null;
        try {
            carte = new File(fic);
            sc = new Scanner(carte);
        }catch(Exception e){
            System.out.println("Erreur ouverture fichier");
        }
    }

    public int nbrLignes(){
        int lignes = 0;
        boolean b = true;
        Scanner compteur = null;
        try {
            compteur = new Scanner(carte);
        }catch(Exception e){
            System.out.println("fichier introuvable");
        }
        while(b){
            if(compteur.hasNextLine()){
                lignes ++;
                compteur.nextLine();
            }else
                b = false;
        }
        compteur.close();
        return lignes;
    }

    public int nbrColonnes(int line){
        int colonnes = 0;
        boolean b = true;
        Scanner compteur = null;
        try {
            compteur = new Scanner(carte);
        }catch(Exception e){
            System.out.println("fichier introuvable");
        }
        int i = 0;
        while(b){
            if (compteur.hasNextLine() && i < line){
                compteur.nextLine();
                i++;
            }else
                b = false;
        }
        b = true;
        while(b){
            if(compteur.hasNextInt() && !sc.hasNext(";")){
                colonnes ++;
                compteur.nextInt();
            }else
                b = false;
        }
        compteur.close();
        return colonnes;
    }

    public boolean sameNbrColonnes(){
        int colonnes = nbrColonnes(0);
        for (int i = 1; i < nbrLignes(); i++){
            int colonnesSuiv = nbrColonnes(i);
            if (colonnesSuiv != colonnes)
                return false;
            else
                colonnes = colonnesSuiv;
        }
        return true;
    }

    private int[] lignePlateau (int l){
        int[] ligne = new int[nbrColonnes(l)];
        for (int i = 0; i < ligne.length; i++){
            ligne[i] = sc.nextInt();
            System.out.print(ligne[i] + " ");
        }
        return ligne;
    }
            
    public Plateau plateau(){
        if (sameNbrColonnes()){
            int[][] terrain = new int[nbrLignes()][nbrColonnes(0)];
            for (int i = 0; i < terrain.length; i++){
                terrain[i] = lignePlateau(i);
                System.out.println();
                if (i < terrain.length-1)
                    sc.nextLine();
            }
            return new Plateau(terrain);
        }else{
            System.out.println("impossible de creer plateau");
            return null;
        }
    }
        

    public static void main(String[] args){
        CarteScanner test = new CarteScanner("carteTest.txt");
        System.out.println(test.nbrLignes());
        System.out.println(test.nbrColonnes(2));
    }
                                  
}
