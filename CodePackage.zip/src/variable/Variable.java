package src.variable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Variable{
  public final static Color foret = new Color(0f,0.50f,0.25f);
  public final static Color plaine = new Color(0f,0.75f,0.50f);
  public final static Color eau = new Color(0f,0.60f,1f);
  public final static Color montagne = new Color(0.60f,0.60f,0.60f);
  public final static Color[] TCou = {foret, plaine, eau, montagne};
  public final static String pathToImages = "src/variable/images/";
  public final static String[] TStrBase = {"foret.jpg", "plaine.jpg", "eau.jpg", "montagne.jpg"};
  public final static String[] TStr;
  public final static long serialVersionUID = 0; //Pour ne pas avoir une erreur jaune à la compilation

  static {
    TStr = new String[TStrBase.length];
    for (int i = 0; i < TStr.length ; i++)
      TStr[i] = pathToImages + TStrBase[i];
  }
}
