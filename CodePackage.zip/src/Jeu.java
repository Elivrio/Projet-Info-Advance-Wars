package src;

import src.controleur.Controleur;
import src.controleur.ControleurKey;
import src.controleur.ControleurMouseMotion;
//import src.controleur.ControleurMouse;
import src.modele.Plateau;
import src.vue.Vue;

public class Jeu {
  private ControleurKey cK;
  // private ControleurMouse cM;
  private ControleurMouseMotion cMM;
  private Vue v;
  private Plateau p;

  public Jeu(int a, int b) {
    p = new Plateau(a,b);
    v = new Vue(p);
    cK = new ControleurKey(v);
    // cM = new ControleurMouse(v);
    cMM = new ControleurMouseMotion(v);
    // cM.initialiserMouseListener(v);  On l'aura au besoin, mais normalement c'est inutile
    v.addMouseMotionListener(cMM);
    v.addKeyListener(cK);
    v.setVisible(true);
  }

  public static void main(String[] args) {
    //System.out.println((float)(80/100));
    Jeu jeu = new Jeu(10,10);
	}
}
