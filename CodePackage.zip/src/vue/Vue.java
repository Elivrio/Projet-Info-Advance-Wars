package src.vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import src.modele.Plateau;
import src.variable.Variable;

public class Vue extends JFrame {

  // Attributs et constructeurs

  final static long serialVersionUID = 0; // Pour ne pas avoir une erreur jaune à la compilation
  private final static int larg = 300;
  private final static int haut = 300;

  private JPanel[] espace = new JPanel[9];
  private Plateau p;
  private int posI;
  private int posJ;
  private int mouse; // Pour le déplacement par la souris

  public Vue(Plateau plat) {
    p = plat;
    GridLayout grille = new GridLayout(3,3);
    setLayout(grille);
    initialiser();
    setSize(larg, haut);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  public Vue(){
    this(new Plateau(10,10));
  }

  // Getters et setters pourris

  public Plateau getPlateau() { return p; }
  public int getPosI() { return posI; }
  public int getPosJ() { return posJ; }
  public int getMouse() { return mouse; }
  public void incPosI (int pI) { posI+= pI; }
  public void incPosJ (int pJ) { posJ += pJ; }
  public void setMouse(int i) { mouse += i; }
  public int getHauteur() { return p.getHauteur(); }
  public int getLargeur() { return p.getLargeur(); }
  public boolean[][] getUnites() { return p.getUnites(); }
  public int[][] getTerrain() { return p.getTerrain(); }
  public JPanel[] getEspace() { return espace; }

  // Méthodes utiles

  public void ajouter(JPanel pan) {
    add(pan);
  }

  public void initialiser() {
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++){
        espace[3*i + j] = new JPanel();
        espace[3*i + j].setBackground(Variable.tCou[p.getTerrain()[i][j]]);
        //ImageIcon im = new ImageIcon(Variable.tStr[p.getTerrain()[i][j]]);
        //espace[3*i + j].add(new JLabel(im));
        JLabel lab = new JLabel(new ImageIcon(Variable.tStr[Variable.tStr.length-1]));
        if (p.getUnites()[posI+i][j+posJ]) {
          System.out.println("là");
          espace[3*i+j].add(lab);
        }
        espace[3*i + j].revalidate();
        add(espace[3*i+j]);
      }
    posI = 0;
    posJ = 0;
    mouse = 0;
  }
}
