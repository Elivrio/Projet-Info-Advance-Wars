package src.unite;

public abstract class Unite{
  int PV;
  String nom;
  int prix;
  int portee;
  int munition;
  int visibilite;
  int essence;
  int deplacement;

  int type; // 0 pour terrestre, 1 pour volante et 2 pour maritime.
}
