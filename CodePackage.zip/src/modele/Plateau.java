package src.modele;

import java.util.Random;

public class Plateau {
  private int largeur, hauteur;
  private int[][] terrain;
  private boolean[][] unites;

  /*
  1 --> Plaine
  3 --> Montagne
  2 --> Eau
  0 --> Foret


  Route, Colline, Pont, etc.
  */

  public Plateau(int l,int h) {
    hauteur = h; largeur = l;
    terrain = new int[l][h];
    unites = new boolean[l][h];
    this.initialiser();
  }

  public int getHauteur() { return hauteur; }
  public int getLargeur() { return largeur; }
  public boolean[][] getUnites() { return unites; }
  public int[][] getTerrain() { return terrain; }

  void initialiser() {
    Random rand = new Random();
    int tmp = 0;
    for (int i = 0; i < hauteur ; i ++) {
      for (int j = 0; j < largeur; j++) {
        tmp = rand.nextInt(4);
        terrain[i][j] = tmp;
        System.out.print(tmp + " ");
      }
      System.out.println();
    }
    int i = rand.nextInt(hauteur);
    int j = rand.nextInt(largeur);
    unites[i][j] = true;
    System.out.println(i + " " + j);
  }

}
