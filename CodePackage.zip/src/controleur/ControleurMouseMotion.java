package src.controleur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import src.variable.Variable;
import src.vue.Vue;

public class ControleurMouseMotion extends Controleur implements MouseMotionListener {

  public ControleurMouseMotion(Vue v) {
    super(v);
  }

  public void mouseMoved(MouseEvent me) {
    // On récupère la taille actuelle de la fenêtre pour utiliser la position du curseur en pourcentage
    // La position en pourcentage est utile dans le cas où on a modifié la taille de la fenêtre
    int sizeY = vue.getHeight();
    int sizeX = vue.getWidth();
    if (vue.getMouse() % 10 == 0) { // Histoire que le déplacement n'aille pas trop vite...
      if (me.getX() >= (80*sizeX/100) && move('d'))
          vue.incPosJ(1);
      if (me.getY() >= (80*sizeY/100) && move('b'))
          vue.incPosI(1);
      if (me.getY() <= (20*sizeY/100) && move('h'))
          vue.incPosI(-1);
      if (me.getX() <= (20*sizeX/100) && move('g'))
          vue.incPosJ(-1);
    }
    vue.setMouse(1);
  }

  public void mouseDragged(MouseEvent me) {}

}
