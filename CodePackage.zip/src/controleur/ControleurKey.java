package src.controleur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import src.variable.Variable;
import src.vue.Vue;

public class ControleurKey extends Controleur implements KeyListener{

  public ControleurKey(Vue v){
    super(v);
  }

  public void keyTyped(KeyEvent evt) {
    if (evt.getKeyChar() == 'd' && move('d'))
        vue.incPosJ(1);
    else if (evt.getKeyChar() == 's' && move('b'))
        vue.incPosI(1);
    else if (evt.getKeyChar() == 'z' && move('h'))
        vue.incPosI(-1);
    else if (evt.getKeyChar() == 'q' && move('g'))
        vue.incPosJ(-1);
  }

  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == KeyEvent.VK_RIGHT && move('d'))
        vue.incPosJ(1);
    else if (e.getKeyCode() == KeyEvent.VK_DOWN && move('b'))
        vue.incPosI(1);
    else if (e.getKeyCode() == KeyEvent.VK_UP && move('h'))
        vue.incPosI(-1);
    else if (e.getKeyCode() == KeyEvent.VK_LEFT && move('g'))
        vue.incPosJ(-1);
  }

  public void keyReleased(KeyEvent e) {}

}
