package src.controleur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import src.variable.Variable;
import src.vue.Vue;

public class ControleurMouse extends Controleur implements MouseListener {

  public ControleurMouse(Vue v) {
    super(v);
  }

  public void initialiserMouseListener(Vue v) {
    JPanel[] espace = v.getEspace();
    for (int i=0; i<9; i++)
      espace[i].addMouseListener(this);
  }

  public void mouseClicked(MouseEvent me) {
    JPanel j = (JPanel) me.getSource();
    JPanel[] espace = vue.getEspace();
    if (j == espace[5] && move('d'))
        vue.incPosJ(1);
    else if (j == espace[7] && move('b'))
        vue.incPosI(1);
    else if (j == espace[1] && move('h'))
        vue.incPosI(-1);
    else if (j == espace[3] && move('g'))
        vue.incPosJ(-1);
  }

  public void mouseExited(MouseEvent me) {}
  public void mouseEntered(MouseEvent me) {}
  public void mouseReleased(MouseEvent me) {}
  public void mousePressed(MouseEvent me) {}
}
