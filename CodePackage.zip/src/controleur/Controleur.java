package src.controleur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import src.variable.Variable;
import src.vue.Vue;


public class Controleur{
  Vue vue;

  public Controleur(Vue v){
    vue = v;
  }

  public boolean move(char c) {
    int accI = 0, accJ = 0;
    int posJ = vue.getPosJ(), posI = vue.getPosI();
    if (c == 'd' && posJ+3 < vue.getLargeur()) accJ++;
    else if (c=='b' && posI+3 < vue.getHauteur()) accI++;
    else if (c=='g' && posJ-1 >= 0) accJ--;
    else if (c=='h' && posI-1 >= 0) accI--;
    else {
      System.out.println("stop");
      return false;
    }
    JPanel[] espace = vue.getEspace();
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++){
        espace[3*i+j].removeAll();
        espace[3*i+j].repaint();
        //espace[3*i+j].setBackground(Variable.TCou[vue.getTerrain()[posI+i+accI][j+posJ+accJ]]);
        espace[3*i + j].add(new JLabel(new ImageIcon(Variable.TStr[vue.getTerrain()[posI+accI+i][posJ+accJ+j]])));
        JLabel lab = new JLabel(new ImageIcon("zombie.png"));
        if (vue.getUnites()[posI+i+accI][j+posJ+accJ]) {
          System.out.println("là");
          espace[3*i+j].add(lab);
        }
        espace[3*i+j].revalidate();
        vue.ajouter(espace[3*i+j]);
      }
    return true;
  }
}
