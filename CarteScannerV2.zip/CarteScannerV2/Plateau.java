package src.modele;

import java.util.Random;

public class Plateau {
    private int largeur, hauteur;
    private int[][][] terrain;
    private int[][][] unites;
    
    /*
      1 --> Plaine
      3 --> Montagne
      2 --> Eau
      0 --> Foret
      
      
      Route, Colline, Pont, etc.
    */
    
    public Plateau(int l,int h) {
        hauteur = h; largeur = l;
        terrain = new int[l][h][2];
        unites = new int[l][h][2];
        this.initialiser();
    }
    
    public Plateau(int[][][] carte, int[][][] armees){
        hauteur = carte[1].length;
        largeur = carte.length;
        terrain = carte;
        unites = armees;
    }
    
    public int getHauteur() { return hauteur; }
    public int getLargeur() { return largeur; }
    public boolean[][][] getUnites() { return unites; }
    public int[][][] getTerrain() { return terrain; }
    
    void initialiser() {
        Random rand = new Random();
        int tmp = 0;
        for (int i = 0; i < hauteur ; i ++) {
            for (int j = 0; j < largeur; j++) {
                tmp = rand.nextInt(4);
                terrain[i][j] = [tmp,0];
                System.out.print(tmp + " ");
            }
            System.out.println();
        }
        int i = rand.nextInt(hauteur);
        int j = rand.nextInt(largeur);
        unites[i][j] = [1,0];
        System.out.println(i + " " + j);
    }
    
}
